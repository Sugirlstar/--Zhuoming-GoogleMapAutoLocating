环境依赖simplekml和pandas，需要提前安装。

使用ipynb只需要更改文件名，文件名必须是xlsx格式，列名必须符合标准。

使用py文件范例如下

```shell
python kml.py 'test.xlsx'
```

输出的kmz格式上传google maps前，需要google maps 先清理图层。